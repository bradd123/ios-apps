//
//  PhotoFrame.swift
//  CoolNotes
//
//  Created by Fernando Rodríguez Romero on 05/04/16.
//  Copyright © 2016 udacity.com. All rights reserved.
//

import Foundation
import CoreData

// MARK: - PhotoFrame: NSManagedObject

class PhotoFrame: NSManagedObject {
    
    // Insert code here to add functionality to your managed object subclass
    
}
